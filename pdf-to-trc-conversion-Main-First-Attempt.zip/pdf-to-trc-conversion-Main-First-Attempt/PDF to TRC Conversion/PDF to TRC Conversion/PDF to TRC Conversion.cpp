// PDF to TRC Conversion.cpp : Defines the entry point for the console application.
//////////////////////////////////////////////////////////////////////////////////
// Made by Cameron Eames and Matt Engesser
// Purpose: To take in the TRC .pdf file and parse through it, 
// spitting out any data needed for TRC compliance for Paragon(tm)
// <Insert legal mumbo jumbo here idk man>
//////////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <iostream>
#include <string>

using namespace std;

int main()
{

	cout << "My name is Matt Engesser and I am lame, press anything if you agree\n\n\n";

	system("pause");

    return 0;
}

